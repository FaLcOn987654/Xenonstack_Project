
function Footer() {

    return (
        <footer class="text-center text-white" style={{ "background-color": "#caced1" }}>
            <div class="text-center p-3" style={{ "background-color": "rgba(0, 0, 0, .88)" }}>
                © 2023 Copyright:
                <a class="text-white">One Plus Pvt. Ltd.</a>
            </div>
        </footer>
    );
}

export default Footer;