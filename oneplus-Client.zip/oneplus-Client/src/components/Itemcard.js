import React from "react";
import { useCart } from "react-use-cart";

const Itemcard = (props) => {

    const { addItem } = useCart();

    return (
        <div className="col-11 col-md-6 col-lg-4 mx-0 mb-4">

            {(console.warn(props.item))}
            <br/><br/>
            <div class="col">
                <br />
                <div class="card h-100 border" style={{ width: "18rem", border: "2px solid black" }}>
                    <img src={props.imagePath} class="card-img-top" style={{height: "235px"}} alt="Image"/>
                    <div class="card-body" style={{backgroundColor:"red"}}>
                        <h5 class="card-title">{props.productName}</h5>
                        <p class="card-text">₹ {props.price}</p>
                        <button class="btn btn-dark" onClick={ () => addItem(props.item) }> Add To Cart </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Itemcard;