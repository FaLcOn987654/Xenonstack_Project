function Home() {
  return (
 <div class="container">
  <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="https://m.media-amazon.com/images/G/31/img23/Wireless/ssserene/GW/May23/BAU/NordCE2lite/D42850095_WLD_OnePlus_OSCAR_NewLaunch_1400x800._CB589852383_.jpg" class="d-block w-100" alt="..."/>
        </div>
      </div>
  </div>
</div>
   
  );
}

export default Home;