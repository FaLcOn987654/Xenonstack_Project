
function AboutUs(){
    return(

  <section>
          <br /><br/>
          <h1 class="heading">
            <span>C</span>
            <span>O</span>
            <span>M</span>
            <span>P</span>
            <span>A</span>
            <span>N</span>
            <span>Y </span>
            <span>O</span>
            <span>V</span>
            <span>E</span>
            <span>R</span>
            <span>V</span>
            <span>I</span>
            <span>E</span>
            <span>W</span>
          </h1>




 <div class="container">
            <div class="row">
              <div class="col-sm"> 
                <i class="fa-solid fa-eye-low-vision"></i>
                <h3>Vision</h3>
                <p>To provide quality services that exceeds the expectations of our esteemed customers.</p>
              </div>
            </div>

            <div class="row">
              <div class="col-sm">
              <i class="fa-sharp fa-solid fa-star"></i>
               <h3>Core Values</h3>
              <p>
               • We believe in treating our customers with respect and faith<br></br>
                 • We grow through creativity, invention and innovation.<br></br>
              • We integrate honesty, integrity and business ethics into all aspects of our business functioning. 
              </p>
              </div>
            </div>

            <div class="row">
              <div class="col-sm"> 

              <i class="fas fa-tasks"></i>
              <h3>Goals</h3>
              <p>
              • Regional expansion in the field of property management & develop a strong base of key customers.<br></br>
 • Increase the assets & investments of the company to support the development of services.<br></br>
            •     To build good reputation in the field of toys industries & become a key player in the industry.
              </p>
              </div>
            </div>

            <div class="box">
              <i class="fas fa-globe-asia"></i>
              <h3>Mission</h3>
              <p>
To build long term relationships with our customers and clients <br/>  & <br/>  provide exceptional customer services by pursuing business through innovation and advanced technology.
              </p>
            </div>

            <div class="box">
              <i class="fas fa-shipping-fast"></i>
              <h3>Purpose</h3>
              <p>
              To be a leader in toys industries by providing enhanced services, relationship and profitability.
              </p>
            </div>

            <div class="box">
              <i class="fas fa-briefcase"></i>
              <h3>Financial Considerations</h3>
              <p>
              The company expects to reach the desired profits in the first year and does not anticipate serious cash flow problems. We believe that the average profitability per month for the first 3 years will be sufficient. 
              </p>
            </div>
          </div> 
        </section>
    );
}

export default AboutUs;