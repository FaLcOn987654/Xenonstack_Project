import axios, { Axios } from "axios";
import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import './Login.css';

class Login extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            password: '',
            emailId: '',
            custId: '',
            checkEmailId: '',
            test: ''
        }
    }

    Handler = (e) => {
        this.setState({ [e.target.name]: e.target.value })
    }

    SubmitHandler = e => {
        e.preventDefault()
        console.log(this.state.password);
        console.log(this.state.emailId);

        axios
            .post("http://localhost:8045/cradle/customer/login", this.state)
            .then(res => {
                localStorage.setItem('customerLoginDetails', JSON.stringify(res.data));
                var xyz = JSON.parse(localStorage.getItem("customerLoginDetails"));

                console.log("Check");
                console.log(typeof (xyz));

                if (xyz.length === 0) {
                    this.state.test = 0;
                } else {
                    this.state.test = 1;
                }

                console.log(this.state.test);
                 if(this.state.test ===0){
                  alert("Invalid id or password.");
                 } 
                 
                this.state.password = xyz[0].password;
                this.state.checkEmailId = xyz[0].emailId;
                if (this.state.test == 1) {
                  alert("Successfully logged in . ");
                  window.location = 'http://localhost:3000/products';
              }
            }
        );
    }

    render() {

        const { password, emailId } = this.state

        return (
          <section class="vh-100">
            
<div class="container h-100">
			<div class="row justify-content-sm-center h-100">
				<div class="col-xxl-4 col-xl-5 col-lg-5 col-md-7 col-sm-9">
					<div class="card shadow-lg">
						<div class="card-body p-5 bg-secondary">
							<h1 class="fs-4 card-title fw-bold mb-4">Login</h1>
							<form onSubmit={this.SubmitHandler} class="needs-validation" autocomplete="off">
              	<div class="mb-3">
									<label class="mb-2 text-uppercase text-align-lg-left font-weight-bold" for="email">E-Mail Address</label>
									<input onChange={this.Handler} value={emailId} name="emailId" id="email" type="email" class="form-control" pattern="^(?!\\d)[a-zA-Z0-9_.]+@[a-zA-Z0-9.-]+$" required autofocus placeholder="Enter Email ID"/>
								</div>

								<div class="mb-3">
									<div class="mb-2 w-100">
										<label class="text-uppercase font-weight-bold" for="password">Password</label>	
									</div>
									<input type="password" onChange={this.Handler} value={password} name="password"  id="password" class="form-control" required placeholder="Enter Password"/>
								</div>

								<div class="d-flex justify-content-center mx-3 mb-3 mb-lg-4">
									<button type="submit" class="btn btn-dark btn-lg">
										Login
									</button> 
                 </div>
							</form>
						</div>
						<div class="card-footer bg-dark py-3 border-0">
							<div class="text-center text-white">
								Don't have an account? <a class="link-danger"> {" "} <Link to="/signup"> Register </Link> </a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
          </section>
        );
    }
}

export default Login;

